# تشغيل اختبارات V230

من tests/integration: npm install ثم npm test للفحوص المعزولة لقاعدة البيانات، وnpm run integrity لفحوص الإصلاحات.
المتصفح: npx playwright install chromium ثم npm run browser. FM_BROWSER_PATH اختياري. لا تستخدم حسابات الإنتاج في هذه الاختبارات.
Auth وStorage وREST موفرات مصطنعة، والمحرك PostgreSQL/PGlite؛ لا يتحقق من كلمة مرور أو خدمة Storage المدارة.
نتائج الإصلاح الحديث في ../results/v230. تقارير وأي نتائج V197 القديمة تاريخية. baseline V229 يستثني فقط التغييرات المقصودة في التوقيع والمؤشرات ودليل الاستخدام وسجل الإصدار.
أداة النسخ اختُبرت بموفرين مصطنعين؛ لا يعتبر ذلك استعادة PostgreSQL حقيقية.

## V231
npm run escalation يشغل 31 فحص SQL للتصعيد. npm run escalation-ui يشغل 10 تجارب للواجهة الفعلية مع قاعدة محلية (يتطلب Chromium؛ FM_BROWSER_PATH اختياري). لا يرسل رسائل لأشخاص. النتائج في tests/results/v231.
